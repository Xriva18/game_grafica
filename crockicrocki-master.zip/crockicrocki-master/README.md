# CrockiCrocki
A personal project of a simple "game" in Python to learn Pygame and Python.

Requires:
pygame:
In Linux:
pip3 install pygame
In MacOS:
pip3 install pygame==2.0.0.dev3

To Run:
python3 cc.py

Future features:
* Cars, turtles and tress to have random X starting points.

