import pygame
import time
import random

# Inicialización
pygame.init()

# Dimensiones de la pantalla
pantallaw = 800
pantallah = 600

# Colores
fondo = (50, 50, 50)
white = (255, 255, 255)
marco = (100, 100, 200)
vereda = (40, 39, 39)
selva = (10, 150, 10)
agua_c = (100, 100, 230)

# Carga de imágenes
crocki = pygame.image.load('crockicrocki.png')
carr = pygame.image.load('carr.png')
carl = pygame.image.load('carl.png')
tortuga = pygame.image.load('tortugas.png')
arbol = pygame.image.load('arbol.png')

# Lista para los “crockis” que logren llegar arriba
crockis = []

# Creación de la ventana
areajuego = pygame.display.set_mode((pantallaw, pantallah))
pygame.display.set_caption('Crocki Crocki - 800x600')

gametimer = pygame.time.Clock()

def text_objects(text, font):
    textSurface = font.render(text, True, white)
    return textSurface, textSurface.get_rect()

def message_display(text, x, y):
    largetext = pygame.font.Font('freesansbold.ttf', 25)
    TextSurf, TextRect = text_objects(text, largetext)
    TextRect.center = (x, y)
    areajuego.blit(TextSurf, TextRect)

# Función de colisión para autos
def obj_colisiones(a, jposx, w):
    """
    Checa si la rana (jposx..jposx+50) colisiona con un auto que va de 'a'..a+w.
    """
    if jposx >= a and jposx <= a + w:
        return True
    elif (jposx + 50) >= a and (jposx + 50) <= a + w:
        return True
    return False

def game_loop():
    # Posición inicial de la rana
    jposx = 750
    jposy = 550

    # Filas de carretera
    # (La carretera va de y=350 a y=500, cada fila = 50 px)
    auto01y = 350
    auto02y = 400
    auto03y = 450

    # Filas de agua
    # (El agua va de y=100 a y=300, cada fila = 50 px)
    agua01y = 100
    agua02y = 150
    agua03y = 200
    agua04y = 250

    # Listas de posiciones X para autos y “troncos”
    # Ajustamos las listas para tener 2 o 3 objetos por fila
    auto01 = [100, 300, 500]
    auto02 = [200, 400, 600]
    auto03 = [150, 350, 550]

    agua01 = [100, 400]   # 2 “troncos” (tortuga) en y=100
    agua02 = [200, 500]   # 2 “troncos” (arbol) en y=150
    agua03 = [100, 300]   # 2 “troncos” (tortuga) en y=200
    agua04 = [250, 550]   # 2 “troncos” (arbol) en y=250

    # Velocidades de movimiento (x)
    # g1mx = derecha, g3mx = izquierda
    g1mx = 5
    g2mx = 3
    g3mx = -4

    # “Ciclos” (tiempo máximo) y puntaje
    ciclos = 3000
    puntaje = 0

    termino = False

    while not termino:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                termino = True
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_0:
                    termino = True
                if event.key == pygame.K_LEFT:
                    jposx = max(0, jposx - 50)
                elif event.key == pygame.K_RIGHT:
                    jposx = min(750, jposx + 50)  # 800 - 50 = 750
                elif event.key == pygame.K_UP:
                    jposy = max(50, jposy - 50)   # No subir más arriba de y=50
                elif event.key == pygame.K_DOWN:
                    jposy = min(550, jposy + 50)  # No bajar más de y=550

        # COLISIONES CON AUTOS (usamos la fila exacta de la rana)
        if jposy == auto03y:  # 450
            for a in auto03:
                if obj_colisiones(a, jposx, 50):
                    termino = True
                    break
        if jposy == auto02y:  # 400
            for a in auto02:
                if obj_colisiones(a, jposx, 50):
                    termino = True
                    break
        if jposy == auto01y:  # 350
            for a in auto01:
                if obj_colisiones(a, jposx, 50):
                    termino = True
                    break

        # COLISIONES EN EL AGUA (basado en rectángulos)
        # Tamaño de la rana = 50×50, tamaño de tronco = 100×50 (por ejemplo)
        frog_rect = pygame.Rect(jposx, jposy, 50, 50)

        # Si la rana está en alguna fila de agua, debe colisionar con un “tronco”
        if jposy == agua04y:  # 250
            notenelagua = False
            for a in agua04:
                log_rect = pygame.Rect(a, agua04y, 100, 50)
                if frog_rect.colliderect(log_rect):
                    notenelagua = True
                    # Moverse con el tronco
                    jposx += g3mx
                    break
            if not notenelagua:
                termino = True

        if jposy == agua03y:  # 200
            notenelagua = False
            for a in agua03:
                log_rect = pygame.Rect(a, agua03y, 100, 50)
                if frog_rect.colliderect(log_rect):
                    notenelagua = True
                    jposx += g2mx
                    break
            if not notenelagua:
                termino = True

        if jposy == agua02y:  # 150
            notenelagua = False
            for a in agua02:
                log_rect = pygame.Rect(a, agua02y, 100, 50)
                if frog_rect.colliderect(log_rect):
                    notenelagua = True
                    jposx += g1mx
                    break
            if not notenelagua:
                termino = True

        if jposy == agua01y:  # 100
            notenelagua = False
            for a in agua01:
                log_rect = pygame.Rect(a, agua01y, 100, 50)
                if frog_rect.colliderect(log_rect):
                    notenelagua = True
                    jposx += g2mx
                    break
            if not notenelagua:
                termino = True

        # LLEGADA A LA META (y=50 => selva)
        if jposy == 50:
            puntaje += 20000
            # Reseteamos la rana abajo
            jposy = 550
            jposx = 750
            crockis.append(jposx)

        # MOVIMIENTOS de autos
        # Avanzan o retroceden en X
        for i in range(len(auto01)):
            auto01[i] += g1mx
            if auto01[i] > 800:  # sale de pantalla, reaparece a la izq
                auto01[i] = -50
        for i in range(len(auto02)):
            auto02[i] += g2mx
            if auto02[i] > 800:
                auto02[i] = -50
        for i in range(len(auto03)):
            auto03[i] += g3mx
            if auto03[i] < -50:
                auto03[i] = 800

        # MOVIMIENTOS de troncos en el agua
        for i in range(len(agua01)):
            agua01[i] += g2mx
            if agua01[i] < -100:
                agua01[i] = 800
            elif agua01[i] > 800:
                agua01[i] = -100

        for i in range(len(agua02)):
            agua02[i] += g1mx
            if agua02[i] > 800:
                agua02[i] = -100

        for i in range(len(agua03)):
            agua03[i] += g2mx
            if agua03[i] < -100:
                agua03[i] = 800
            elif agua03[i] > 800:
                agua03[i] = -100

        for i in range(len(agua04)):
            agua04[i] += g3mx
            if agua04[i] < -100:
                agua04[i] = 800
            elif agua04[i] > 800:
                agua04[i] = -100

        # DIBUJAR FONDO Y MARCOS
        areajuego.fill(fondo)

        # Barra superior (0..50)
        pygame.draw.rect(areajuego, marco, [0, 0, pantallaw, 50])
        # Barra inferior (550..600)
        pygame.draw.rect(areajuego, marco, [0, 550, pantallaw, 50])
        # Selva (50..100)
        pygame.draw.rect(areajuego, selva, [0, 50, pantallaw, 50])
        # Agua (100..300)
        pygame.draw.rect(areajuego, agua_c, [0, 100, pantallaw, 200])
        # Vereda (300..350)
        pygame.draw.rect(areajuego, vereda, [0, 300, pantallaw, 50])
        # Carretera (350..500)
        pygame.draw.rect(areajuego, (70, 70, 70), [0, 350, pantallaw, 150])
        # Vereda (500..550)
        pygame.draw.rect(areajuego, vereda, [0, 500, pantallaw, 50])

        # Mensajes
        message_display(f"Ciclos restantes: {ciclos}", 250, 580)
        message_display(f"Puntaje de Crockis salvados: {puntaje}", 250, 20)

        # DIBUJAR OBJETOS DEL AGUA
        for a in agua01:
            areajuego.blit(tortuga, (a, agua01y))
        for a in agua02:
            areajuego.blit(arbol, (a, agua02y))
        for a in agua03:
            areajuego.blit(tortuga, (a, agua03y))
        for a in agua04:
            areajuego.blit(arbol, (a, agua04y))

        # DIBUJAR RANA
        areajuego.blit(crocki, (jposx, jposy))

        # DIBUJAR AUTOS
        for a in auto01:
            areajuego.blit(carr, (a, auto01y))
        for a in auto02:
            areajuego.blit(carr, (a, auto02y))
        for a in auto03:
            areajuego.blit(carl, (a, auto03y))

        # DIBUJAR CROCKIS SALVADOS ARRIBA
        for a in crockis:
            areajuego.blit(crocki, (a, 50))

        pygame.display.update()
        gametimer.tick(60)
        ciclos -= 1
        if ciclos <= 0:
            termino = True

    if puntaje == 0:
        ciclos = 0
    return ciclos + puntaje

def main():
    areajuego.fill(fondo)
    score = game_loop()

    time.sleep(2)
    areajuego.fill(fondo)
    for a in crockis:
        areajuego.blit(crocki, (a, 50))
    message_display("Puntaje total: " + str(score), 400, 300)
    pygame.display.update()
    print("Tu score fue:", score)
    time.sleep(4)
    pygame.quit()
    quit()

if __name__ == "__main__":
    main()
